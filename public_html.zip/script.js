// Show loading
const loadingDiv = document.createElement("div");
loadingDiv.id = "loading";
loadingDiv.innerHTML = "<div class='spinner'></div><p>Loading data...</p>";
document.body.appendChild(loadingDiv);

// Load CSV file
fetch("data/Customer_Segmentation_Result.csv")
.then(res => {
    if (!res.ok) throw new Error("Failed to load CSV file");
    return res.text();
})
.then(csv => {
    // Hide loading
    loadingDiv.style.display = "none";

    const rows = csv.split("\n").map(e => e.split(","));
    const header = rows[0];
    const data = rows.slice(1);

    let clusterCounts = [0, 0, 0, 0];
    let rfmAvg = [
        {R:0, F:0, M:0, count:0},
        {R:0, F:0, M:0, count:0},
        {R:0, F:0, M:0, count:0},
        {R:0, F:0, M:0, count:0},
    ];

    const tbody = document.querySelector("#dataTable tbody");
    let allRows = [];
    let filteredRows = [];
    const rowsPerPage = 50;
    let currentPage = 1;
    let currentSort = { column: null, direction: 'asc' };

    data.forEach(row => {
        if(row.length < 5) return;

        let cust = row[0];
        let R = parseFloat(row[1]);
        let F = parseFloat(row[2]);
        let M = parseFloat(row[3]);
        let C = parseInt(row[4]);

        clusterCounts[C]++;

        rfmAvg[C].R += R;
        rfmAvg[C].F += F;
        rfmAvg[C].M += M;
        rfmAvg[C].count++;

        allRows.push({cust, R, F, M, C});
    });

    function sortRows(column, direction) {
        allRows.sort((a, b) => {
            let aVal = a[column];
            let bVal = b[column];
            if (typeof aVal === 'string') {
                aVal = aVal.toLowerCase();
                bVal = bVal.toLowerCase();
            }
            if (direction === 'asc') {
                return aVal > bVal ? 1 : aVal < bVal ? -1 : 0;
            } else {
                return aVal < bVal ? 1 : aVal > bVal ? -1 : 0;
            }
        });
    }

    function filterRows(query) {
        if (!query) {
            filteredRows = [...allRows];
        } else {
            filteredRows = allRows.filter(row =>
                row.cust.toLowerCase().includes(query.toLowerCase()) ||
                row.C.toString().includes(query)
            );
        }
        allRows = [...filteredRows];
        currentPage = 1;
    }

    function exportCSV() {
        const csvContent = "CustomerID,Recency,Frequency,Monetary,Cluster\n" +
            allRows.map(row => `${row.cust},${row.R},${row.F},${row.M},${row.C}`).join("\n");
        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement("a");
        const url = URL.createObjectURL(blob);
        link.setAttribute("href", url);
        link.setAttribute("download", "filtered_customer_data.csv");
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }

    function displayPage(page) {
        tbody.innerHTML = "";
        const start = (page - 1) * rowsPerPage;
        const end = start + rowsPerPage;
        const pageRows = allRows.slice(start, end);

        pageRows.forEach(row => {
            tbody.innerHTML += `
                <tr>
                    <td>${row.cust}</td>
                    <td>${row.R}</td>
                    <td>${row.F}</td>
                    <td>${row.M}</td>
                    <td>${row.C}</td>
                </tr>
            `;
        });
    }

    function renderPagination() {
        const paginationDiv = document.getElementById("pagination");
        paginationDiv.innerHTML = "";

        const totalPages = Math.ceil(allRows.length / rowsPerPage);

        // Previous button
        const prevBtn = document.createElement("button");
        prevBtn.textContent = "Previous";
        prevBtn.disabled = currentPage === 1;
        prevBtn.onclick = () => {
            if (currentPage > 1) {
                currentPage--;
                displayPage(currentPage);
                renderPagination();
            }
        };
        paginationDiv.appendChild(prevBtn);

        // Page numbers
        for (let i = 1; i <= totalPages; i++) {
            const pageBtn = document.createElement("button");
            pageBtn.textContent = i;
            pageBtn.className = i === currentPage ? "active" : "";
            pageBtn.onclick = () => {
                currentPage = i;
                displayPage(currentPage);
                renderPagination();
            };
            paginationDiv.appendChild(pageBtn);
        }

        // Next button
        const nextBtn = document.createElement("button");
        nextBtn.textContent = "Next";
        nextBtn.disabled = currentPage === totalPages;
        nextBtn.onclick = () => {
            if (currentPage < totalPages) {
                currentPage++;
                displayPage(currentPage);
                renderPagination();
            }
        };
        paginationDiv.appendChild(nextBtn);
    }

    displayPage(currentPage);
    renderPagination();

    // Summary Cards
    const cardDiv = document.getElementById("cluster-cards");
    clusterCounts.forEach((count, i) => {
        cardDiv.innerHTML += `
            <div class="card">
                <h3>Cluster ${i}</h3>
                <p>Total Pelanggan: <b>${count}</b></p>
            </div>`;
    });

    // Pie Chart
    new Chart(document.getElementById("clusterPie"), {
        type: "pie",
        data: {
            labels: ["Loyal Customer", "At-Risk", "Best Spenders", "Big Spenders"],
            datasets: [{
                data: clusterCounts,
                backgroundColor: ["#4a6cf7", "#ffae00", "#ff5e57", "#6c757d"],
                hoverBackgroundColor: ["#3a5ce7", "#e69500", "#e64c4c", "#5a6268"]
            }]
        },
        options: {
            responsive: true,
            plugins: {
                title: {
                    display: true,
                    text: 'Distribusi Cluster Pelanggan',
                    font: {
                        size: 18,
                        weight: 'bold'
                    }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const label = context.label || '';
                            const value = context.parsed;
                            const total = context.dataset.data.reduce((a, b) => a + b, 0);
                            const percentage = ((value / total) * 100).toFixed(1);
                            return `${label}: ${value} (${percentage}%)`;
                        }
                    }
                },
                legend: {
                    position: 'bottom'
                }
            },
            animation: {
                animateScale: true,
                animateRotate: true
            }
        }
    });

    // Radar Chart RFM
    const R = rfmAvg.map(x => x.R / x.count);
    const F = rfmAvg.map(x => x.F / x.count);
    const M = rfmAvg.map(x => x.M / x.count);

    new Chart(document.getElementById("rfmRadar"), {
        type: "radar",
        data: {
            labels: ["Loyal Customer", "At-Risk", "Best Spenders", "Big Spenders"],
            datasets: [
                {label:"Recency", data:R, borderColor:"#4a6cf7", backgroundColor:"rgba(74, 108, 247, 0.2)", fill:true, pointBackgroundColor:"#4a6cf7", pointBorderColor:"#fff", pointBorderWidth:2, pointRadius:6},
                {label:"Frequency", data:F, borderColor:"#ffae00", backgroundColor:"rgba(255, 174, 0, 0.2)", fill:true, pointBackgroundColor:"#ffae00", pointBorderColor:"#fff", pointBorderWidth:2, pointRadius:6},
                {label:"Monetary", data:M, borderColor:"#ff5e57", backgroundColor:"rgba(255, 94, 87, 0.2)", fill:true, pointBackgroundColor:"#ff5e57", pointBorderColor:"#fff", pointBorderWidth:2, pointRadius:6}
            ]
        },
        options: {
            responsive: true,
            plugins: {
                title: {
                    display: true,
                    text: 'Rata-rata RFM per Cluster',
                    font: {
                        size: 18,
                        weight: 'bold'
                    }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return `${context.dataset.label}: ${context.parsed.r.toFixed(2)}`;
                        }
                    }
                },
                legend: {
                    position: 'top'
                }
            },
            scales: {
                r: {
                    beginAtZero: true,
                    grid: {
                        color: 'rgba(0,0,0,0.1)',
                        lineWidth: 2
                    },
                    angleLines: {
                        color: 'rgba(0,0,0,0.2)',
                        lineWidth: 2
                    },
                    pointLabels: {
                        font: {
                            size: 14,
                            weight: 'bold'
                        },
                        color: '#333'
                    },
                    ticks: {
                        display: false
                    }
                }
            },
            animation: {
                duration: 2000,
                easing: 'easeInOutQuart'
            }
        }
    });

    // Bar Chart RFM
    new Chart(document.getElementById("rfmBar"), {
        type: "bar",
        data: {
            labels: ["Loyal Customer", "At-Risk", "Best Spenders", "Big Spenders"],
            datasets: [
                {
                    label: "Recency",
                    data: R,
                    backgroundColor: "#4a6cf7",
                    borderColor: "#3a5ce7",
                    borderWidth: 1
                },
                {
                    label: "Frequency",
                    data: F,
                    backgroundColor: "#ffae00",
                    borderColor: "#e69500",
                    borderWidth: 1
                },
                {
                    label: "Monetary",
                    data: M,
                    backgroundColor: "#ff5e57",
                    borderColor: "#e64c4c",
                    borderWidth: 1
                }
            ]
        },
        options: {
            responsive: true,
            plugins: {
                title: {
                    display: true,
                    text: 'Perbandingan RFM Antar Cluster',
                    font: {
                        size: 18,
                        weight: 'bold'
                    }
                },
                tooltip: {
                    mode: 'index',
                    intersect: false
                },
                legend: {
                    position: 'top'
                }
            },
            scales: {
                y: {
                    beginAtZero: true
                }
            },
            animation: {
                duration: 1500,
                easing: 'easeInOutBounce'
            }
        }
    });

    // Event listeners
    document.querySelectorAll(".sortable").forEach(th => {
        th.addEventListener("click", () => {
            const column = th.dataset.column;
            if (currentSort.column === column) {
                currentSort.direction = currentSort.direction === 'asc' ? 'desc' : 'asc';
            } else {
                currentSort.column = column;
                currentSort.direction = 'asc';
            }
            sortRows(column, currentSort.direction);
            displayPage(currentPage);
            renderPagination();
        });
    });

    document.getElementById("exportBtn").addEventListener("click", exportCSV);

})
.catch(error => {
    loadingDiv.innerHTML = "<p style='color: red;'>Error loading data: " + error.message + "</p>";
});
